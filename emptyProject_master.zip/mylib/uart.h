#ifndef _UART_H_
#define _UART_H_
#include "driverlib.h"
#include "delay.h"
extern unsigned char co_data;
extern unsigned char openmv_data[3];
bool UART_Init(uint16_t baseAddress, uint32_t Baudrate);//���ڳ�ʼ��
#endif
