#ifndef _LED_H_
#define _LED_H_
#include "driverlib.h"
void led_init(void);//led��ʼ��
#endif
