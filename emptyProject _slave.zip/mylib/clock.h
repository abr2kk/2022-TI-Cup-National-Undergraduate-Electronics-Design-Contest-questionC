#ifndef _CLOCK_H_
#define _CLOCK_H_
#include "driverlib.h"
#include "delay.h"
void SystemClock_Init(void);//ϵͳʱ�ӳ�ʼ��
#endif
