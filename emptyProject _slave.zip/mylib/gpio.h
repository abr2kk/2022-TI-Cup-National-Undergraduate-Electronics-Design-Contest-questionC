#ifndef _GPIO_H_
#define _GPIO_H_
#include "driverlib.h"
extern int counter_left,counter_right;
void set_interrupt_(uint8_t selectedPort, uint16_t selectedPins);

#endif
