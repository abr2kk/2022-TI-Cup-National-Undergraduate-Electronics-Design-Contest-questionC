#include "msp430f5529.h"
#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_
#include "driverlib.h"

#define Trig_Port GPIO_PORT_P8
#define Trig_Pin  GPIO_PIN1
#define Echo_Port GPIO_PORT_P2
#define Echo_Pin  GPIO_PIN3

#define CPU_CLOCK       16000000
#define delay_us(us)    __delay_cycles(CPU_CLOCK/1000000*(us))

void wave_Init(void);
void wave_star(void);

#endif /* ULTRASONIC_H_ */
