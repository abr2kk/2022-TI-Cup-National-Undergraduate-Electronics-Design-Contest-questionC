#ifndef _TIMER_H_
#define _TIMER_H_
#include "driverlib.h"
#include "delay.h"
extern char timer_20ms;
void Timer_A_Init(char timerAx);//��ʱ��A���ú���
void Timer_A_PWM_Init(char timerAx);
#endif
