#include "timer.h"
char timer_20ms=0;
void Timer_A_Init(char timerAx)
{
    Timer_A_initUpModeParam htim = {0};
    htim.clockSource = TIMER_A_CLOCKSOURCE_SMCLK;    //ʱ��ԴѡΪ25M
    htim.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_40;   //40��Ƶ
    htim.timerPeriod = 12500-1;                                 //����ֵ��Ϊ12500 - 1
    htim.timerInterruptEnable_TAIE = TIMER_A_TAIE_INTERRUPT_DISABLE;
    htim.captureCompareInterruptEnable_CCR0_CCIE = TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE;      //ʹ��CCR0�ж�
    htim.timerClear = TIMER_A_DO_CLEAR; //�Ѷ�ʱ���Ķ�ʱ����������Ƶ�������ļ���ֵ����
    htim.startTimer = true;             //��ʼ��������������ʱ��
    switch(timerAx)//ѡ��ʱ��
    {
    case 0:Timer_A_initUpMode(TIMER_A0_BASE, &htim);break;
    case 1:Timer_A_initUpMode(TIMER_A1_BASE, &htim);break;
    case 2:Timer_A_initUpMode(TIMER_A2_BASE, &htim);break;
    default:while(1);
    }
}
//��ʱ��A0�жϷ�����
#pragma vector=TIMER0_A0_VECTOR
__interrupt
void TIMER0_A0_ISR (void)
{
    GPIO_toggleOutputOnPin(GPIO_PORT_P4, GPIO_PIN7);
    //write your codes
}
//��ʱ��A1�жϷ�����
#pragma vector=TIMER1_A0_VECTOR
__interrupt
void TIMER1_A0_ISR (void)
{
    timer_20ms=1;
    //GPIO_toggleOutputOnPin(GPIO_PORT_P4, GPIO_PIN7);
    //write your codes
}
////��ʱ��A2�жϷ�����
//#pragma vector=TIMER2_A0_VECTOR
//__interrupt
//void TIMER2_A0_ISR (void)
//{
//    GPIO_toggleOutputOnPin(GPIO_PORT_P4, GPIO_PIN7);
//    //write your codes
//}




#define TIMER_PERIOD 2000
void Timer_A_PWM_Init(char timerAx)
{
    Timer_A_outputPWMParam htim = {0};

    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P1, GPIO_PIN2);
    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P1, GPIO_PIN3);
    htim.clockSource = TIMER_A_CLOCKSOURCE_SMCLK;
    htim.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_1;
    htim.timerPeriod = TIMER_PERIOD - 1;
    htim.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_1;
    htim.compareOutputMode = TIMER_A_OUTPUTMODE_RESET_SET;
    htim.dutyCycle = TIMER_PERIOD / 2;
    switch(timerAx)//ѡ��ʱ��
    {
    case 0:Timer_A_outputPWM(TIMER_A0_BASE, &htim);break;
    case 1:Timer_A_outputPWM(TIMER_A1_BASE, &htim);break;
    case 2:Timer_A_outputPWM(TIMER_A2_BASE, &htim);break;
    default:while(1);
    }
    htim.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_2;
    switch(timerAx)//ѡ��ʱ��
    {
    case 0:Timer_A_outputPWM(TIMER_A0_BASE, &htim);break;
    case 1:Timer_A_outputPWM(TIMER_A1_BASE, &htim);break;
    case 2:Timer_A_outputPWM(TIMER_A2_BASE, &htim);break;
    default:while(1);
    }
    //Timer_A_outputPWM(TIMER_A0_BASE, &htim);
}
//Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,5000);//��������ռ�ձ�
