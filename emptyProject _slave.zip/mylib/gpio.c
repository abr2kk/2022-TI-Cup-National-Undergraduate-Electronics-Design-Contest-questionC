#include "gpio.h"
int counter_left=0,counter_right=0;//���ҵ������ֵ


void set_interrupt_(uint8_t selectedPort, uint16_t selectedPins)
{
    GPIO_setAsInputPinWithPullUpResistor(selectedPort, selectedPins);
    //P2.1 interrupt enabled
    GPIO_enableInterrupt(selectedPort, selectedPins);  //ʹ���ж�

    //P2.1 Hi/Lo edge
    GPIO_selectInterruptEdge(selectedPort, selectedPins, GPIO_HIGH_TO_LOW_TRANSITION); //�����ж�����

    //P2.1 IFG cleared
    GPIO_clearInterrupt(selectedPort, selectedPins);   //����жϱ�־λ
}
#pragma vector=PORT2_VECTOR     // P2���ж�Դ
__interrupt
void Port_2 (void)              // ����һ���жϷ��������ΪPort_2()
{
//    if(GPIO_getInterruptStatus(GPIO_PORT_P2, GPIO_PIN1))
//    {
//        delay_ms(20);
//        if(!GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN1))
//        {
//            //P1.0 = toggle
//            GPIO_toggleOutputOnPin(GPIO_PORT_P1, GPIO_PIN0);
//
//            while(!GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN1));
//        }
//        //P2.1 IFG cleared
//        GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN1);
//    }
    if(GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN5))
        counter_right++;
    else
        counter_right--;
    GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN4);
}
#pragma vector=PORT1_VECTOR     // P1���ж�Դ
__interrupt
void Port_1 (void)              // ����һ���жϷ��������ΪPort_1()
{
    //GPIO_toggleOutputOnPin(GPIO_PORT_P4, GPIO_PIN7);
    if(GPIO_getInputPinValue(GPIO_PORT_P1, GPIO_PIN5))
        counter_left++;
    else
        counter_left--;
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
}


